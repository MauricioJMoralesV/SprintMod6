# Spring-BootMysql
Ejercicio Grupal. Desarrollo Aplicacion Sprint boot
# Spring-BootMysql
Ejercicio Grupal. Desarrollo Aplicacion Sprint boot
Proyecto de Asesorías en Prevención de Riesgos Laborales - README
Integrantes:
    Aracily Morales    
    Ricardo Cea        
    Simón Zelada       
    Eduado Torres      
    Mauricio Morales   https://github.com/MauricioJMoralesV/SprintMod6.git

Resumen del Proyecto:

Este es el repositorio del proyecto de Asesorías en Prevención de Riesgos Laborales, que busca desarrollar una solución tecnológica para una compañía de asesoría en prevención de riesgos. El sistema permitirá administrar procesos, coordinar actividades, gestionar clientes y mejorar la seguridad laboral en la plataforma.
Aspectos Relevantes:
    Tecnologías utilizadas: Java Enterprise Edition (JEE), JavaServer Faces (JSF), base de datos.
    Casos de uso desarrollados: Página de inicio, formulario de contacto, creación y listado de capacitaciones, inicio de sesión con RUT y clave de Clientes,     Profesionales y Administrativo.
    Casos de uso adicionales: Gestión de usuarios, administración de visitas a terreno, respuesta a checklist de visitas, listado y creación de pagos.
    Interfaz de usuario mejorada para una experiencia amigable y eficiente.
    Desarrollo basado en metodología ágil.

Repositorio GitHub:

El código fuente y la documentación completa se encuentran en este enlace:

https://github.com/aaracily/Spring-BootMysql.git

El proyecto se encuentra en la rama Ricardo: https://github.com/aaracily/Spring-BootMysql/tree/ricardo
Instrucciones de Ejecución:
    -Clonar el repositorio desde GitHub.
    -Configurar el entorno JEE y un servidor de aplicaciones compatible.
    -Importar el proyecto en el IDE.
    -Configurar la conexión a la base de datos.
    -Compilar y desplegar la aplicación en el servidor.
    -Acceder a la URL del sistema y utilizar las credenciales de inicio de sesión correspondientes para cada tipo de usuario.


	Base de datos se encuentra en carpeta "baseDatos" con las respectivas tablas

    ACCESOS SPRING SECURITY:

	- cliente: user: cliente1 -> pass: 1010
	- profesional: user: prof1 -> pass: 3030
	- administrativo: user: admin1 -> pass: 2020
